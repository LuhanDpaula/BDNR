using LivrosApp.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LivrosApp.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;

    public HomeController(AppDbContext db) => _db = db;

    // Home: tabela com todos os livros (título, autor, status)
    public async Task<IActionResult> Index()
    {
        var livros = await _db.Livros.OrderBy(l => l.Titulo).ToListAsync();
        return View(livros);
    }
}
