using LivrosApp.Data;
using LivrosApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LivrosApp.Controllers;

public class TransacoesController : Controller
{
    private readonly AppDbContext _db;

    public TransacoesController(AppDbContext db) => _db = db;

    // ---------- EMPRESTAR ----------
    public async Task<IActionResult> Emprestar()
    {
        await CarregarEmprestar();
        return View();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Emprestar(int livroId, int alunoId)
    {
        var livro = await _db.Livros.FindAsync(livroId);
        var alunoExiste = await _db.Alunos.AnyAsync(a => a.AlunoId == alunoId);

        // Regra de negócio: só empresta se o livro existe e está disponível.
        if (livro == null || !alunoExiste || livro.Status != StatusLivro.Disponivel)
        {
            ModelState.AddModelError("", "Não foi possível emprestar: verifique o livro e o aluno.");
            await CarregarEmprestar();
            return View();
        }

        livro.Status = StatusLivro.Emprestado;   // 1) muda o status
        _db.Transacoes.Add(new Transacao         // 2) registra a transação
        {
            LivroId = livroId,
            AlunoId = alunoId,
            Tipo = TipoTransacao.Emprestimo,
            DataTransacao = DateTime.Now
        });
        await _db.SaveChangesAsync();            // salva as duas coisas juntas

        TempData["Msg"] = $"\"{livro.Titulo}\" emprestado com sucesso.";
        return RedirectToAction("Index", "Home");
    }

    // ---------- DEVOLVER ----------
    public async Task<IActionResult> Devolver()
    {
        await CarregarDevolver();
        return View();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Devolver(int livroId)
    {
        var livro = await _db.Livros.FindAsync(livroId);

        if (livro == null || livro.Status != StatusLivro.Emprestado)
        {
            ModelState.AddModelError("", "Esse livro não está emprestado.");
            await CarregarDevolver();
            return View();
        }

        // Descobre quem estava com o livro: o último empréstimo dele.
        var ultimoEmprestimo = await _db.Transacoes
            .Where(t => t.LivroId == livroId && t.Tipo == TipoTransacao.Emprestimo)
            .OrderByDescending(t => t.TransacaoId)
            .FirstOrDefaultAsync();

        if (ultimoEmprestimo == null)
        {
            ModelState.AddModelError("", "Não encontrei o empréstimo desse livro.");
            await CarregarDevolver();
            return View();
        }

        livro.Status = StatusLivro.Disponivel;
        _db.Transacoes.Add(new Transacao
        {
            LivroId = livroId,
            AlunoId = ultimoEmprestimo.AlunoId,
            Tipo = TipoTransacao.Devolucao,
            DataTransacao = DateTime.Now
        });
        await _db.SaveChangesAsync();

        TempData["Msg"] = $"\"{livro.Titulo}\" devolvido com sucesso.";
        return RedirectToAction("Index", "Home");
    }

    private async Task CarregarEmprestar()
    {
        var livros = await _db.Livros.Where(l => l.Status == StatusLivro.Disponivel).OrderBy(l => l.Titulo).ToListAsync();
        var alunos = await _db.Alunos.OrderBy(a => a.Nome).ToListAsync();
        ViewBag.Livros = new SelectList(livros, "LivroId", "Titulo");
        ViewBag.Alunos = new SelectList(alunos, "AlunoId", "Nome");
    }

    private async Task CarregarDevolver()
    {
        var livros = await _db.Livros.Where(l => l.Status == StatusLivro.Emprestado).OrderBy(l => l.Titulo).ToListAsync();
        ViewBag.Livros = new SelectList(livros, "LivroId", "Titulo");
    }
}
