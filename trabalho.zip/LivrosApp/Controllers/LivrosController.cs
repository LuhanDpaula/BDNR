using LivrosApp.Data;
using LivrosApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace LivrosApp.Controllers;

public class LivrosController : Controller
{
    private readonly AppDbContext _db;

    public LivrosController(AppDbContext db) => _db = db;

    // Link "Livros" do menu: abre o formulário de cadastro.
    public IActionResult Create() => View(new Livro());

    // [Bind] aceita só Titulo e Autor vindos do formulário;
    // o Status é definido aqui, no servidor, e nunca pelo usuário.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Titulo,Autor")] Livro livro)
    {
        if (!ModelState.IsValid) return View(livro);

        livro.Status = StatusLivro.Disponivel;
        _db.Livros.Add(livro);
        await _db.SaveChangesAsync();

        TempData["Msg"] = $"Livro \"{livro.Titulo}\" cadastrado!";
        return RedirectToAction("Index", "Home");
    }
}
