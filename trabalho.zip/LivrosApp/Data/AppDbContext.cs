using LivrosApp.Models;
using Microsoft.EntityFrameworkCore;

namespace LivrosApp.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Livro> Livros { get; set; }
    public DbSet<Aluno> Alunos { get; set; }
    public DbSet<Transacao> Transacoes { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Alunos de exemplo (o enunciado permite cadastrar direto no banco).
        modelBuilder.Entity<Aluno>().HasData(
            new Aluno { AlunoId = 1, Nome = "Ana Souza" },
            new Aluno { AlunoId = 2, Nome = "Bruno Lima" },
            new Aluno { AlunoId = 3, Nome = "Carla Mendes" });
    }
}
