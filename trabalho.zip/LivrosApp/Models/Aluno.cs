using System.ComponentModel.DataAnnotations;

namespace LivrosApp.Models;

public class Aluno
{
    public int AlunoId { get; set; }

    [Required, StringLength(100)]
    public string Nome { get; set; }
}
