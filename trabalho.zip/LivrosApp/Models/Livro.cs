using System.ComponentModel.DataAnnotations;

namespace LivrosApp.Models;

public static class StatusLivro
{
    public const string Disponivel = "Disponível";
    public const string Emprestado = "Emprestado";
}

public class Livro
{
    public int LivroId { get; set; }

    [Required(ErrorMessage = "Informe o título")]
    [StringLength(150)]
    [Display(Name = "Título")]
    public string Titulo { get; set; }

    [Required(ErrorMessage = "Informe o autor")]
    [StringLength(100)]
    public string Autor { get; set; }

    // Valor inicial: "Disponível"
    [StringLength(20)]
    public string Status { get; set; } = StatusLivro.Disponivel;
}
