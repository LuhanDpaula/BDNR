using System.ComponentModel.DataAnnotations;

namespace LivrosApp.Models;

public static class TipoTransacao
{
    public const string Emprestimo = "Empréstimo";
    public const string Devolucao = "Devolução";
}

// Cada empréstimo ou devolução vira UMA LINHA aqui (um "histórico").
public class Transacao
{
    public int TransacaoId { get; set; }

    public int LivroId { get; set; }
    public Livro Livro { get; set; }

    public int AlunoId { get; set; }
    public Aluno Aluno { get; set; }

    [Required, StringLength(20)]
    public string Tipo { get; set; }

    public DateTime DataTransacao { get; set; }
}
