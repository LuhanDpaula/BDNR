using EventosApp.Models;
using Microsoft.EntityFrameworkCore;

namespace EventosApp.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    // Cada DbSet vira uma TABELA no banco.
    public DbSet<PerfilProfissional> PerfisProfissionais { get; set; }
    public DbSet<Participante> Participantes { get; set; }
    public DbSet<Tipo> Tipos { get; set; }
    public DbSet<Patrocinador> Patrocinadores { get; set; }
    public DbSet<Evento> Eventos { get; set; }
    public DbSet<Inscricao> Inscricoes { get; set; }
    public DbSet<Certificado> Certificados { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Dados iniciais (entram no banco junto com a Migration),
        // para as listas de Tipo e Patrocinador não ficarem vazias.
        modelBuilder.Entity<Tipo>().HasData(
            new Tipo { TipoId = 1, Descritivo = "Palestra" },
            new Tipo { TipoId = 2, Descritivo = "Workshop" },
            new Tipo { TipoId = 3, Descritivo = "Hackathon" });

        modelBuilder.Entity<Patrocinador>().HasData(
            new Patrocinador { PatrocinadorId = 1, NomeEmpresa = "TechCorp", Website = "https://techcorp.example" },
            new Patrocinador { PatrocinadorId = 2, NomeEmpresa = "DevHouse", Website = "https://devhouse.example" });
    }
}
