using EventosApp.Data;
using EventosApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventosApp.Controllers;

public class EventosController : Controller
{
    private readonly AppDbContext _db;

    public EventosController(AppDbContext db) => _db = db;

    // LISTA: Include() "traz junto" Tipo e Patrocinador (é o JOIN do SQL),
    // assim a tela mostra o nome da empresa e o descritivo, e não os IDs.
    public async Task<IActionResult> Index()
    {
        var eventos = await _db.Eventos
            .Include(e => e.Tipo)
            .Include(e => e.Patrocinador)
            .OrderBy(e => e.DataEvento)
            .ToListAsync();
        return View(eventos);
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();
        var evento = await BuscarCompleto(id.Value);
        if (evento == null) return NotFound();
        return View(evento);
    }

    // CREATE (GET): mostra o formulário vazio
    public IActionResult Create()
    {
        CarregarListas();
        return View(new Evento { DataEvento = DateTime.Today });
    }

    // CREATE (POST): recebe o formulário preenchido
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Evento evento)
    {
        if (ModelState.IsValid)
        {
            _db.Add(evento);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        CarregarListas(evento.TipoId, evento.PatrocinadorId);
        return View(evento);
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();
        var evento = await _db.Eventos.FindAsync(id);
        if (evento == null) return NotFound();
        CarregarListas(evento.TipoId, evento.PatrocinadorId);
        return View(evento);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Evento evento)
    {
        if (id != evento.EventoId) return NotFound();
        if (ModelState.IsValid)
        {
            _db.Update(evento);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        CarregarListas(evento.TipoId, evento.PatrocinadorId);
        return View(evento);
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();
        var evento = await BuscarCompleto(id.Value);
        if (evento == null) return NotFound();
        return View(evento);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var evento = await _db.Eventos.FindAsync(id);
        if (evento != null)
        {
            _db.Eventos.Remove(evento);
            await _db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private Task<Evento> BuscarCompleto(int id) =>
        _db.Eventos.Include(e => e.Tipo).Include(e => e.Patrocinador)
            .FirstOrDefaultAsync(e => e.EventoId == id);

    // Prepara as listas (dropdowns) de Tipo e Patrocinador para o formulário.
    private void CarregarListas(int? tipoId = null, int? patrocinadorId = null)
    {
        ViewBag.Tipos = new SelectList(_db.Tipos.OrderBy(t => t.Descritivo), "TipoId", "Descritivo", tipoId);
        ViewBag.Patrocinadores = new SelectList(_db.Patrocinadores.OrderBy(p => p.NomeEmpresa), "PatrocinadorId", "NomeEmpresa", patrocinadorId);
    }
}
