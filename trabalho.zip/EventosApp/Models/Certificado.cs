using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosApp.Models;

public class Certificado
{
    public int CertificadoId { get; set; }

    public int InscricaoId { get; set; }
    public Inscricao Inscricao { get; set; }

    [Column(TypeName = "date")]
    [DataType(DataType.Date)]
    public DateTime DataEmissao { get; set; }

    [StringLength(100)]
    public string Link { get; set; }
}
