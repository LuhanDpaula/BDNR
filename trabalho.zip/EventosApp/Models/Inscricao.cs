using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosApp.Models;

public class Inscricao
{
    public int InscricaoId { get; set; }

    public int EventoId { get; set; }
    public Evento Evento { get; set; }

    public int ParticipanteId { get; set; }
    public Participante Participante { get; set; }

    [Column(TypeName = "date")]
    [DataType(DataType.Date)]
    public DateTime DataInscricao { get; set; }
}
