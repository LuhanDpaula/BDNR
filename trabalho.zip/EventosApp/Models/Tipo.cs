using System.ComponentModel.DataAnnotations;

namespace EventosApp.Models;

public class Tipo
{
    public int TipoId { get; set; }

    [Required, StringLength(80)]
    public string Descritivo { get; set; }
}
