using System.ComponentModel.DataAnnotations;

namespace EventosApp.Models;

public class PerfilProfissional
{
    public int PerfilProfissionalId { get; set; }

    [Required, StringLength(100)]
    public string Descritivo { get; set; }

    [StringLength(100)]
    public string LinkedinUrl { get; set; }
}
