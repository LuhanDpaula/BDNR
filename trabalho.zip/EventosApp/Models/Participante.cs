using System.ComponentModel.DataAnnotations;

namespace EventosApp.Models;

public class Participante
{
    public int ParticipanteId { get; set; }

    [Required, StringLength(100)]
    public string Nome { get; set; }

    [Required, StringLength(100)]
    public string Email { get; set; }

    [StringLength(15)]
    public string Celular { get; set; }

    [StringLength(8)]
    public string Senha { get; set; }

    // Chave estrangeira + propriedade de navegação (Participante N --- 1 PerfilProfissional)
    public int PerfilProfissionalId { get; set; }
    public PerfilProfissional PerfilProfissional { get; set; }
}
