using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosApp.Models;

public class Evento
{
    public int EventoId { get; set; }

    [Required(ErrorMessage = "Informe o título")]
    [StringLength(100)]
    [Display(Name = "Título")]
    public string Titulo { get; set; }

    [StringLength(250)]
    [Display(Name = "Descrição")]
    public string Descricao { get; set; }

    [Required]
    [Column(TypeName = "date")]
    [DataType(DataType.Date)]
    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    [Display(Name = "Data do evento")]
    public DateTime DataEvento { get; set; }

    // Evento N --- 1 Tipo
    [Display(Name = "Tipo")]
    public int TipoId { get; set; }
    public Tipo Tipo { get; set; }

    // Evento N --- 1 Patrocinador
    [Display(Name = "Patrocinador")]
    public int PatrocinadorId { get; set; }
    public Patrocinador Patrocinador { get; set; }
}
