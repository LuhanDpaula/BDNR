using System.ComponentModel.DataAnnotations;

namespace EventosApp.Models;

public class Patrocinador
{
    public int PatrocinadorId { get; set; }

    [Required, StringLength(100)]
    public string NomeEmpresa { get; set; }

    [StringLength(100)]
    public string Website { get; set; }
}
