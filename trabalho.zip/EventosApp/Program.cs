using EventosApp.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Lê a "string de conexão" do appsettings.json e diz ao EF Core: "use MySQL".
var conexao = builder.Configuration.GetConnectionString("Default");
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseMySql(conexao, new MySqlServerVersion(new Version(8, 0, 36))));

var app = builder.Build();

// Ao iniciar, aplica as Migrations pendentes (cria o banco e as tabelas se não existirem).
using (var scope = app.Services.CreateScope())
{
    scope.ServiceProvider.GetRequiredService<AppDbContext>().Database.Migrate();
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Eventos}/{action=Index}/{id?}");

app.Run();
